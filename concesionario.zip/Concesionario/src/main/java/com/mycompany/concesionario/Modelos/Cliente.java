/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.concesionario.Modelos;

/**
 *
 * @author melipilla
 */
public class Cliente {
    private String rut, NombreCompleto, email;
    private String telefono;

    public Cliente() {
        rut="";
        NombreCompleto="";
        email="";
        telefono="";
    }

    public Cliente(String rut, String NombreCompleto, String email) {
        this.rut = rut;
        this.NombreCompleto = NombreCompleto;
        this.email = email;
        telefono="";
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombreCompleto() {
        return NombreCompleto;
    }

    public void setNombreCompleto(String NombreCompleto) {
        this.NombreCompleto = NombreCompleto;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    
}
