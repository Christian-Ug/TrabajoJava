/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.concesionario;

import com.mycompany.concesionario.Vista.VistaCliente;

/**
 *
 * @author melipilla
 */
public class Concesionario {

    public static void main(String[] args) {
      VistaCliente vistacliente = new VistaCliente();
      vistacliente.setVisible(true);
      
    }
}
