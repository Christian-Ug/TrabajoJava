/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.concesionario.Controladores;

import com.mycompany.concesionario.Interface.ClienteDAO;
import com.mycompany.concesionario.Modelos.AdministradorCliente;
import com.mycompany.concesionario.Vista.VistaCliente;

/**
 *
 * @author Christian Ugarte
 */
public class ClienteControler {
    private VistaCliente vistaCliente;
    private ClienteDAO clienteDao;
    
    public ClienteControler (VistaCliente vistaCliente){
        this.vistaCliente=vistaCliente;
        clienteDao= new AdministradorCliente();
        AgregarListeners();
    }

    private void AgregarListeners() {
        //vistaCliente.getBtnAgregar().addActionListeners(new ActionListeners)()
        
    
    }
    
}
