/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.concesionario.Interface;

import com.mycompany.concesionario.Modelos.Cliente;
import java.util.ArrayList;

/**
 *
 * @author melipilla
 */
public interface ClienteDAO {
    
    String crearCliente (String rut, String NombreCompleto,String email, String Telefono);
    boolean eliminarCliente(String rut);
    ArrayList<Cliente>obtenerClientes();
    boolean editarCliente(String rut, String NombreCompleto, String email, String telefono);
    Cliente BuscarCliente(String rut);
    
}
