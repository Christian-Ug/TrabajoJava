/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.concesionario.Modelos;

import com.mycompany.concesionario.Interface.ClienteDAO;
import java.util.ArrayList;

/**
 *
 * @author melipilla
 */
public class AdministradorCliente implements ClienteDAO{
    
    ArrayList<Cliente> listaClientes;

    public AdministradorCliente(){
        listaClientes=new ArrayList();
    }

    @Override
    public String crearCliente(String rut, String NombreCompleto, String email, String telefono) {
        if(rut.length()!=10){
            return "Debe ingresar el rut correctamente";
        }else if(!email.contains("@")){
            return "Debe ingresar el email correctamente";
            
        }else if(NombreCompleto.length()<4){
            return "Debe ingresar el nombre correctamente";
        }else{
            for(Cliente clienteGuardado: listaClientes){
                if(clienteGuardado.getRut().equalsIgnoreCase(rut)){
                    return "El cliente ya existe";
                }
            }
        }
        Cliente nuevoCliente= new Cliente(rut, NombreCompleto,email);
        nuevoCliente.setTelefono(telefono);
        listaClientes.add(nuevoCliente);
        return "Cliente creado exitosamente";
        
    }

    @Override
    public boolean eliminarCliente(String rut) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<Cliente> obtenerClientes() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean editarCliente(String rut, String NombreCompleto, String email, String telefono) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Cliente BuscarCliente(String rut) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
